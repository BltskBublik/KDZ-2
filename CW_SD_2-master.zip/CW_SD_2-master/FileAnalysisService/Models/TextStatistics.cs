namespace FileAnalysisService.Models;

public class TextStatistics
{
    public int Paragraphs { get; set; }
    public int Words { get; set; }
    public int Characters { get; set; }
}